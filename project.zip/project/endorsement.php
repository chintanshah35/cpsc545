<div class="wrapper style3">
					<div class="title">The Endorsements</div>
					<div id="highlights" class="container">
						<div class="row 150%">
							<div class="4u 12u(mobile)">
								<section class="highlight">
									<a href="healthy-dining.php" class="image featured"><img src="http://dining.okstate.edu/sites/dining.okstate.edu/files/images/HealthyDiningLogo2012_Transparency2.png" alt="Healthy Dining" height="142" width="279" /></a>
									<h3><a href="healthy-dining.php">Healthy Dining</a></h3>
									<ul class="actions">
										<li><a href="healthy-dining.php" class="button style1">Learn More</a></li>
									</ul>
								</section>
							</div>
							
							<div class="4u 12u(mobile)">
								<section class="highlight">
									<a href="exercise-tips.php" class="image featured"><img src="http://supercirclefitness.com/wp-content/uploads/2015/03/Super-Circle-Logo-transparent1.png" alt="Excercise Tips" height="142" width="279" /></a>
									<h3><a href="exercise-tips.php">Exercise Tips</a></h3>
									<ul class="actions">
										<li><a href="exercise-tips.php" class="button style1">Learn More</a></li>
									</ul>
								</section>
							</div>
							
							<div class="4u 12u(mobile)">
								<section class="highlight">
									<a href="healthy-recipes.php" class="image featured"><img src="http://images.clipartpanda.com/fruits-and-vegetables-pictures-vegetables-clipart-McLXM7xca.png" alt="Food Guide" height="142" width="279" /></a>
									<h3><a href="healthy-recipes.php">Healthy Recipes</a></h3>
									<ul class="actions">
										<li><a href="healthy-recipes.php" class="button style1">Learn More</a></li>
									</ul>
								</section>
							</div>
							
						</div>
					</div>
				</div>
