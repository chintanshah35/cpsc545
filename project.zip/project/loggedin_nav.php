<nav id="nav">
	<ul>
		<li class="current"><a href="template.php">Home</a></li>
		<li><a href="welcome.php">My Account</a>
			<ul>
				<li><a href="welcome.php">My Profile</a></li>
				<li class="current"><a href="mymenu.php">My Menu</a></li>
			</ul>
		</li>
		
		<li>
			<a href="diabetes-info.php">Information</a>
			<ul>
				<li><a href="diabetes-info.php">Diabetes Info</a></li>
				<li><a href="cholestrol-info.php">Cholestrol Info</a></li>
				<li><a href="hypertension-info.php">Hypertension Info</a></li>
				<li><a href="obesity-info.php">Obesity Info</a></li>
			</ul>
		</li>
		
		
		<li><a href="healthy-dining.php">Dining & Receipes</a>
			<ul>
				<li><a href="healthy-dining.php">Healthy Dining</a></li>
				<li><a href="healthy-recipes.php">Healthy Recipes</a></li>
			</ul>
		</li>
		
		<li><a href="health-blog.php">Blogs and Tips</a>
		<ul>
				<li><a href="health-blog.php">Health Blog</a></li>
				<li><a href="exercise-tips.php">Exercise Tips</a></li>
			</ul>
		</li>
		<li>
			<a href="urgentcare.php">Emergency Contact</a>
			<ul>
				<li><a href="urgentcare.php">Urgent Care</a></li>
				<li><a href="hospital.php">Hospital</a></li>
			</ul>
		</li>
		<li><a href="logout.php?logout">Logout</a></li>
	</ul>
</nav>